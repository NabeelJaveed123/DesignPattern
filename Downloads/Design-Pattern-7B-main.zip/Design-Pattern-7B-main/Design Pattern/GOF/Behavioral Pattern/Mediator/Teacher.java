/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GOF.DP_Lab5.Mediator.LabTask;

/**
 *
 * @author Zain
 */
public class Teacher extends User{
    public Teacher(String name) {
        super(name);
    }
}
